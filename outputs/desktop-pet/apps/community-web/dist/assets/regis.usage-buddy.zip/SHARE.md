# AI 额度伙伴

作者：Regis Benedito dos Santos Bittencourt
来源：https://github.com/regisbsb/openpets-plugin-usage-buddy
许可声明：MIT；原始版权声明见包内 LICENSE

以上为填写者声明，未经平台核实。

在本地控制中心「插件管理」导入 ZIP 或文件夹，确认权限后启用。其他宿主插件需要适配后才能运行。

本包保留上传的作品文件。分享前确认其中没有密钥、私人配置或聊天记录。请保留原包、作者声明和许可证。

维护者：Lykinzlj

## 安装与配置

这是在 desktop pet 本机运行的插件。下载 ZIP 并解压，导入含插件清单的文件夹后确认权限；启停、配置、授权和插件数据仍由本地控制中心管理。

需要用户另行运行 usage-monitor-for-claude-and-codex 本机监控程序，并确认插件可访问其 127.0.0.1:45455 端点；插件本身不直接读取云端账号额度。
