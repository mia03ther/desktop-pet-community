# St. Tibo Reset

作者：wynn
来源：https://github.com/legeling/awesome-codex-pet/tree/0d0f06bb1721aef4ddbc7f893276f235ed8458ec/pets/st-tibo-reset--wynn
许可声明：Non-commercial use and redistribution only, with credit to wynn, to the extent the contributor holds rights in this work. Reference imagery and the depicted person's rights remain with their respective rightsholders and are not licensed by this submission. Unofficial fan art; no affiliation or endorsement is claimed. These terms do not establish third-party rights clearance. Please contact the contributor or maintainers with rights concerns so the submission can be reviewed, revised, or removed.

以上为填写者声明，未经平台核实。

在本地控制中心「我的桌宠」导入 ZIP。

本包保留上传的作品文件。分享前确认其中没有密钥、私人配置或聊天记录。请保留原包、作者声明和许可证。
