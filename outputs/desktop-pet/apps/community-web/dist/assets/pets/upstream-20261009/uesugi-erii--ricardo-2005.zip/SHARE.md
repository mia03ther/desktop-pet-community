# 上杉绘梨衣codex宠物

作者：Ricardo-2005
来源：https://github.com/legeling/awesome-codex-pet/tree/0d0f06bb1721aef4ddbc7f893276f235ed8458ec/pets/uesugi-erii--ricardo-2005
许可声明：CC BY-NC 4.0；仅限非商业使用。非官方 AI 同人作品，不代表或暗示获得原作品权利方授权；角色及商标权利归其权利人所有。

以上为填写者声明，未经平台核实。

在本地控制中心「我的桌宠」导入 ZIP。

本包保留上传的作品文件。分享前确认其中没有密钥、私人配置或聊天记录。请保留原包、作者声明和许可证。
