# St. Tibo Reset 归属与素材许可

作者：wynn

固定提交：0d0f06bb1721aef4ddbc7f893276f235ed8458ec

原作品与投稿资料：https://github.com/legeling/awesome-codex-pet/tree/0d0f06bb1721aef4ddbc7f893276f235ed8458ec/pets/st-tibo-reset--wynn

原素材声明：https://github.com/legeling/awesome-codex-pet/blob/0d0f06bb1721aef4ddbc7f893276f235ed8458ec/ASSETS-LICENSE.md

投稿者的完整原条款：

Non-commercial use and redistribution only, with credit to wynn, to the extent the contributor holds rights in this work. Reference imagery and the depicted person's rights remain with their respective rightsholders and are not licensed by this submission. Unofficial fan art; no affiliation or endorsement is claimed. These terms do not establish third-party rights clearance. Please contact the contributor or maintainers with rights concerns so the submission can be reviewed, revised, or removed.

本次改变：pet.json、submission.json 与 spritesheet.webp 原件逐字节保留。仅新增本站分享说明和归属资料；网页缩略图截取自原图集，原图集不改写。

许可范围：上面的声明记录投稿者对其可许可贡献的授权。角色、商标、参考图、肖像及其他第三方权利不因本包取得额外许可；未独立取得这些权利人的授权证明。仓库代码的MIT与素材许可分开，原仓库代码许可另留在 ORIGINAL-REPOSITORY-LICENSE。
