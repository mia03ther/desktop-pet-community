本素材为 Codex V2 透明待机兼容副本。原中性待机格完全透明，仅把原待机行第 1 格逐像素无损复制到第 7 格。原三件文件按原名、原字节存放于 original/upstream-original.zip；根 pet.json 与 submission.json 保持原字节。其他动作行、16 个视线格、图集尺寸与原授权声明未变。未生成角色、美术、动作或新时序。
