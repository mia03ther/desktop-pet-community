# Memmy · 记忆伙伴

作者：MemTensor

原始项目：https://github.com/MemTensor/memmy-agent/tree/e7868e8dcca6ec52424a6535a8dbac4215708e2d

许可：MIT。原始版权声明见包内 LICENSE；保留原作者。

安装：在控制中心“我的桌宠”导入本 ZIP 并设为当前桌宠。仅提供包内实际存在的动作；缺少状态回退待机。本包为桌宠素材适配，不复制原宿主的全部业务与养成逻辑。
