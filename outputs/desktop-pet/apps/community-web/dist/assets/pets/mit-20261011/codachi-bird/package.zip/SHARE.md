author: blairjordan
source: https://github.com/blairjordan/codachi/tree/d24a6ebdc357cf1daff2c49b940fba4f4c0b66a7
license: MIT根原文；官方原创图声明随原README，未发现独立素材例外。
