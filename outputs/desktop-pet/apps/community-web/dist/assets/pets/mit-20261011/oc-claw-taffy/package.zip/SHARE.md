author: rainnoon
source: https://github.com/rainnoon/oc-claw/tree/4667c8c082cecf7e38440dfc2f6f89f7a9b6cc90
license: 代码MIT；美术非商业，只限学习、演示和个人使用，商业产品须替换全部美术。完整原LICENSE随包。
