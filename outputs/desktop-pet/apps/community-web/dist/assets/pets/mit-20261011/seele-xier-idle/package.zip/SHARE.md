author: xinna2001（上游维护者；代码原版权 PYmili）
source: https://github.com/xinna2001/Seele/tree/49089a444a5bd3045898009094d15f0f49742e96
license: 代码MIT；角色与美术未见独立授权声明。本包是私有验证候选，尚未公开上架。
