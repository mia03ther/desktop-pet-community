# 胡桃 · WindowPet

作者：SeakMengs

原始项目：https://github.com/SeakMengs/WindowPet/tree/aba8d3ab94d30f4f5abf92b3f3ec7dff50d3326b

许可：代码 MIT；角色美术依原作者声明。原始版权声明见包内 LICENSE；保留原作者。

安装：在控制中心“我的桌宠”导入本 ZIP 并设为当前桌宠。仅提供包内实际存在的动作；缺少状态回退待机。本包为桌宠素材适配，不复制原宿主的全部业务与养成逻辑。
