# 藤原千花

作者：klmklmnb
来源：https://github.com/legeling/awesome-codex-pet/tree/651b811bee953e4d2dedd2f61440d1921b60fd49/pets/fujiwara-chika--klmklmnb
许可声明：Non-commercial use only. Unofficial independently AI-generated fan art submitted by klmklmnb for non-commercial repository redistribution; no official affiliation or endorsement. The original character and related intellectual property belong to their respective rights holders.

以上为填写者声明，未经平台核实。

在本地控制中心「我的桌宠」导入 ZIP。

本包保留上传的作品文件。分享前确认其中没有密钥、私人配置或聊天记录。请保留原包、作者声明和许可证。
