# 赫萝

作者：James991116
来源：https://github.com/legeling/awesome-codex-pet/tree/651b811bee953e4d2dedd2f61440d1921b60fd49/pets/holo--james991116
许可声明：Non-commercial use only. This is unofficial independently AI-generated fan art submitted by James991116 for non-commercial repository use. Holo and Spice and Wolf rights remain with their respective owners; no official affiliation or endorsement is implied.

以上为填写者声明，未经平台核实。

在本地控制中心「我的桌宠」导入 ZIP。

本包保留上传的作品文件。分享前确认其中没有密钥、私人配置或聊天记录。请保留原包、作者声明和许可证。
