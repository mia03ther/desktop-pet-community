# 高松灯

作者：A1w
来源：https://github.com/legeling/awesome-codex-pet/tree/651b811bee953e4d2dedd2f61440d1921b60fd49/pets/takamatsu-tomori--a1wace-dev
许可声明：Non-commercial use only. AI-assisted fan-art Codex pet adaptation by A1w; no official affiliation or commercial use permitted.

以上为填写者声明，未经平台核实。

在本地控制中心「我的桌宠」导入 ZIP。

本包保留上传的作品文件。分享前确认其中没有密钥、私人配置或聊天记录。请保留原包、作者声明和许可证。
