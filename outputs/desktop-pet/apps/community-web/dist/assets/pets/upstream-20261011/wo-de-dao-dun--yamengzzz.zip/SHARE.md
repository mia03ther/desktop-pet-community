# 我的刀盾狗

作者：YamengZZZ
来源：https://github.com/legeling/awesome-codex-pet/tree/651b811bee953e4d2dedd2f61440d1921b60fd49/pets/wo-de-dao-dun--yamengzzz
许可声明：仅限非商业使用，禁止商用 / Non-commercial use only. 最终动画适配署名 YamengZZZ；原始角色及参考图权利归各自权利人，不声称拥有其权利或获得其认可。

以上为填写者声明，未经平台核实。

在本地控制中心「我的桌宠」导入 ZIP。

本包保留上传的作品文件。分享前确认其中没有密钥、私人配置或聊天记录。请保留原包、作者声明和许可证。
