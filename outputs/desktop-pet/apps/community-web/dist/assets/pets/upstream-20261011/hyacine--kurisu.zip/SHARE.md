# 风堇

作者：Kurisu
来源：https://github.com/legeling/awesome-codex-pet/tree/651b811bee953e4d2dedd2f61440d1921b60fd49/pets/hyacine--kurisu
许可声明：仅限个人非商业使用。AI 辅助制作的非官方同人作品，不代表或暗示已获得米哈游/HoYoverse 授权；《崩坏：星穹铁道》角色及商标权利归其权利人所有。

以上为填写者声明，未经平台核实。

在本地控制中心「我的桌宠」导入 ZIP。

本包保留上传的作品文件。分享前确认其中没有密钥、私人配置或聊天记录。请保留原包、作者声明和许可证。
