# 韩立元婴

作者：legeling
来源：https://github.com/legeling/awesome-codex-pet/tree/651b811bee953e4d2dedd2f61440d1921b60fd49/pets/han-li-nascent-soul--legeling
许可声明：Independent AI-generated community interpretation; non-commercial use only. Commercial use is prohibited.

以上为填写者声明，未经平台核实。

在本地控制中心「我的桌宠」导入 ZIP。

本包保留上传的作品文件。分享前确认其中没有密钥、私人配置或聊天记录。请保留原包、作者声明和许可证。
