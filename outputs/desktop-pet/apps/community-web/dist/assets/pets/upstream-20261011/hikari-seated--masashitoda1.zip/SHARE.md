# 橘光·坐姿

作者：MasashiToda1
来源：https://github.com/legeling/awesome-codex-pet/tree/651b811bee953e4d2dedd2f61440d1921b60fd49/pets/hikari-seated--masashitoda1
许可声明：仅限非商业使用，禁止商用。允许本仓库收录、展示及分发此独立 AI 生成的同人宠物及预览；非官方作品，不代表获得角色权利方授权。角色及商标权利归各自权利人所有。

以上为填写者声明，未经平台核实。

在本地控制中心「我的桌宠」导入 ZIP。

本包保留上传的作品文件。分享前确认其中没有密钥、私人配置或聊天记录。请保留原包、作者声明和许可证。
