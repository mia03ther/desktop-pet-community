# 韩立·结婴

作者：metro186
来源：https://github.com/legeling/awesome-codex-pet/tree/651b811bee953e4d2dedd2f61440d1921b60fd49/pets/han-li--metro186
许可声明：Non-commercial use only. Independent AI-assisted fan-art interpretation of Han Li from A Record of a Mortal's Journey to Immortality (凡人修仙传). Character appearance and costume were guided by official and public references; the final spritesheet is independently generated and does not directly copy, crop, trace, or redistribute reference-image pixels. This submission is not affiliated with, endorsed by, or sponsored by the rights holder.

以上为填写者声明，未经平台核实。

在本地控制中心「我的桌宠」导入 ZIP。

本包保留上传的作品文件。分享前确认其中没有密钥、私人配置或聊天记录。请保留原包、作者声明和许可证。
