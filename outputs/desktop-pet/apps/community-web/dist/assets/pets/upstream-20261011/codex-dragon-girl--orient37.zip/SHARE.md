# Codex龙娘·居家版

作者：orient37（AI 辅助制作）
来源：https://github.com/legeling/awesome-codex-pet/tree/651b811bee953e4d2dedd2f61440d1921b60fd49/pets/codex-dragon-girl--orient37
许可声明：仅限非商业使用。角色创作署名按请求保留为 ZipZipPipe；不宣称拥有原角色或参考图的权利，也不为参考图授予额外许可。

以上为填写者声明，未经平台核实。

在本地控制中心「我的桌宠」导入 ZIP。

本包保留上传的作品文件。分享前确认其中没有密钥、私人配置或聊天记录。请保留原包、作者声明和许可证。
