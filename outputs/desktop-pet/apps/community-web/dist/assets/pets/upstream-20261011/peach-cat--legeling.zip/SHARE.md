# 蜜桃猫

作者：legeling
来源：https://github.com/legeling/awesome-codex-pet/tree/651b811bee953e4d2dedd2f61440d1921b60fd49/pets/peach-cat--legeling
许可声明：Non-commercial use only. Independently AI-generated unofficial fan art. Character design: 不觉晓晓 / Bu Jue Xiao Xiao. Peach and Goma character rights remain with their respective owners. No third-party reference pixels are redistributed. No endorsement or license to the underlying character or third-party reference artwork is implied.

以上为填写者声明，未经平台核实。

在本地控制中心「我的桌宠」导入 ZIP。

本包保留上传的作品文件。分享前确认其中没有密钥、私人配置或聊天记录。请保留原包、作者声明和许可证。
