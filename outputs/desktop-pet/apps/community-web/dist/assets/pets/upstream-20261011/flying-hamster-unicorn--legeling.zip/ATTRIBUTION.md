# Flying Hamster Unicorn 归属与素材许可

作者：legeling

固定提交：651b811bee953e4d2dedd2f61440d1921b60fd49

原作品与投稿资料：https://github.com/legeling/awesome-codex-pet/tree/651b811bee953e4d2dedd2f61440d1921b60fd49/pets/flying-hamster-unicorn--legeling

原素材声明：https://github.com/legeling/awesome-codex-pet/blob/651b811bee953e4d2dedd2f61440d1921b60fd49/ASSETS-LICENSE.md

投稿者的完整原条款：

Non-commercial use only. Commercial use is prohibited. Character rights remain with their respective owners.

原条款范围：原文未明确授权本站再分发，不能以非商业使用推定。本站收录不修改这些限制，也不授予新的使用、修改、再分发或商用权利；需另行许可时请联系原权利人。

本次改变：pet.json、submission.json 与 spritesheet.webp 原件逐字节保留。仅新增本站分享说明和归属资料；网页缩略图截取自原图集，原图集不改写。

许可范围：上面的声明记录投稿者对其可许可贡献的授权。角色、商标、参考图、肖像及其他第三方权利不因本包取得额外许可；未独立取得这些权利人的授权证明。仓库代码的MIT与素材许可分开，原仓库代码许可另留在 ORIGINAL-REPOSITORY-LICENSE。
