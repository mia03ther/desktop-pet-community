# 自嘲熊

作者：z.kzhang
来源：https://github.com/legeling/awesome-codex-pet/tree/651b811bee953e4d2dedd2f61440d1921b60fd49/pets/zichao-xiong--z-kzhang
许可声明：Original AI-generated Codex pet based on a user-provided plush-bear reference. This is not an official Nagano/Jikochu Kuma asset and does not include copied logos, text, or original copyrighted artwork. Permission granted by the creator/uploader for inclusion in the awesome-codex-pet gallery.

以上为填写者声明，未经平台核实。

在本地控制中心「我的桌宠」导入 ZIP。

本包保留上传的作品文件。分享前确认其中没有密钥、私人配置或聊天记录。请保留原包、作者声明和许可证。
