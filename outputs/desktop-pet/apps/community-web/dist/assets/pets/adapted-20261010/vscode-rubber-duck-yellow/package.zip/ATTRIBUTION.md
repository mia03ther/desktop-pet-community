# VSCode Pets 小黄鸭

作者：Marc Duiker。代码项目：Anthony Shaw 与 VSCode Pets 贡献者。

许可证：MIT，完整文本见 LICENSE.txt。本包仅选取作者本人在 MIT 仓库贡献的 GIF；当前主仓原件与作者分支的 Git blob SHA 全部一致。

作者仓库： https://github.com/marcduiker/vscode-pets/tree/ac75fc09468b2eb6b4ba23a05c4dadfa143b11ab/media/rubber-duck
作者仓库 MIT： https://github.com/marcduiker/vscode-pets/blob/ac75fc09468b2eb6b4ba23a05c4dadfa143b11ab/LICENSE
作者贡献： https://github.com/tonybaloney/vscode-pets/pull/30
固定上游： https://github.com/tonybaloney/vscode-pets/tree/6554662a53ef093b7598598b77e51f95128a1f38/media/rubber-duck

处理：GIF 完整合成帧转无损动画 WebP；保持画布、可见像素、透明度与实际每帧延时。原文件名中的 8fps 仅是名称，以原 GIF 的真实延时为准。

重复源动作映射：{"walk-fast": "run"}。这些重复素材未增加为新视觉动作。

此包接入本系统的动作播放器与已声明状态；原 VSCode 扩展的移动、扔球、追球、碰撞和好友行为引擎未移植。单个方向运动由本宿主控制与翻转。
