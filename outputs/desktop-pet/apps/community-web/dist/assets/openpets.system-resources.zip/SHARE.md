# 系统资源

作者：Karim Bouwmans
来源：https://github.com/OpenPetsHQ/Openpets-system-resources
许可声明：MIT；原始版权声明见包内 LICENSE

以上为填写者声明，未经平台核实。

在本地控制中心「插件管理」导入 ZIP 或文件夹，确认权限后启用。其他宿主插件需要适配后才能运行。

本包保留上传的作品文件。分享前确认其中没有密钥、私人配置或聊天记录。请保留原包、作者声明和许可证。

维护者：Lykinzlj

## 安装与配置

这是在 desktop pet 本机运行的插件。下载 ZIP 并解压，导入含插件清单的文件夹后确认权限；启停、配置、授权和插件数据仍由本地控制中心管理。
