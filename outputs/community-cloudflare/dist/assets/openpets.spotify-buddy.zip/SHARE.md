# Spotify 音乐伙伴

作者：OpenPets contributors
来源：https://github.com/OpenPetsHQ/openpets/tree/2d14120cf027c9e80db7ff78e60711be08d39df4/plugins/community/openpets.spotify-buddy
许可声明：MIT；原始版权声明见包内 LICENSE

以上为填写者声明，未经平台核实。

在本地控制中心「插件管理」导入 ZIP 或文件夹，确认权限后启用。其他宿主插件需要适配后才能运行。

本包保留上传的作品文件。分享前确认其中没有密钥、私人配置或聊天记录。请保留原包、作者声明和许可证。

维护者：Lykinzlj

## 安装与配置

这是在 desktop pet 本机运行的插件。下载 ZIP 并解压，导入含插件清单的文件夹后确认权限；启停、配置、授权和插件数据仍由本地控制中心管理。

需要在本机插件配置提供可用的 Spotify 应用 Client ID，再通过插件命令完成账号授权；当前源码使用宿主 OAuth，不要求旧 README 中的 ngrok 桥接。播放控制还受 Spotify 账号和服务权限限制。
