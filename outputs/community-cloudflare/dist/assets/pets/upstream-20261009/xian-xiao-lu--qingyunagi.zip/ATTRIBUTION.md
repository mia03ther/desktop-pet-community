# Xian Xiao Lu 归属与素材许可

作者：qingyunAGI

固定提交：0d0f06bb1721aef4ddbc7f893276f235ed8458ec

原作品与投稿资料：https://github.com/legeling/awesome-codex-pet/tree/0d0f06bb1721aef4ddbc7f893276f235ed8458ec/pets/xian-xiao-lu--qingyunagi

原素材声明：https://github.com/legeling/awesome-codex-pet/blob/0d0f06bb1721aef4ddbc7f893276f235ed8458ec/ASSETS-LICENSE.md

素材许可直达链接：https://opensource.org/license/mit

投稿者的完整原条款：

MIT License

本次改变：pet.json、submission.json 与 spritesheet.webp 原件逐字节保留。仅新增本站分享说明和归属资料；网页缩略图截取自原图集，原图集不改写。

许可范围：上面的声明记录投稿者对其可许可贡献的授权。角色、商标、参考图、肖像及其他第三方权利不因本包取得额外许可；未独立取得这些权利人的授权证明。仓库代码的MIT与素材许可分开，原仓库代码许可另留在 ORIGINAL-REPOSITORY-LICENSE。
