# Lil Swole

作者：gg0805
来源：https://github.com/legeling/awesome-codex-pet/tree/0d0f06bb1721aef4ddbc7f893276f235ed8458ec/pets/lil-swole--gg0805
许可声明：CC BY-NC 4.0. Original AI-generated artwork created for and submitted by gg0805; no third-party source assets were used.

以上为填写者声明，未经平台核实。

在本地控制中心「我的桌宠」导入 ZIP。

本包保留上传的作品文件。分享前确认其中没有密钥、私人配置或聊天记录。请保留原包、作者声明和许可证。
