# Mochi · 像素伙伴

作者：miflow13

原始项目：https://github.com/miflow13/mochi-desktop/tree/471342631206c40d56bbba016578926e16ca8d0b

许可：MIT。原始版权声明见包内 LICENSE；保留原作者。

安装：在控制中心“我的桌宠”导入本 ZIP 并设为当前桌宠。仅提供包内实际存在的动作；缺少状态回退待机。本包为桌宠素材适配，不复制原宿主的全部业务与养成逻辑。
