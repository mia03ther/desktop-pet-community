# 圆滚滚小黑鲸

作者：PolinniZhong

原始项目：https://github.com/PolinniZhong/dsh-personal-center/tree/731a2593c2e32012781effd276a082b95d9b63fc

许可：MIT。原始版权声明见包内 LICENSE；保留原作者。

安装：在控制中心“我的桌宠”导入本 ZIP 并设为当前桌宠。仅提供包内实际存在的动作；缺少状态回退待机。本包为桌宠素材适配，不复制原宿主的全部业务与养成逻辑。
