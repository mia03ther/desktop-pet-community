# 补补 Bubu

作者：NanmiCoder

原始项目：https://github.com/NanmiCoder/cc-haha/tree/1443e22d4657ebe9b662d567cd51f6684ddddd03

许可：MIT。原始版权声明见包内 LICENSE；保留原作者。

安装：在控制中心“我的桌宠”导入本 ZIP 并设为当前桌宠。仅提供包内实际存在的动作；缺少状态回退待机。本包为桌宠素材适配，不复制原宿主的全部业务与养成逻辑。
