# oneko 经典白猫

原 xneko：Masayuki Koba；oneko 改造：Tatsuya Kato；后续：John Lerchey、Eric Anderson、Toshihiro Kanda、Kiichiroh Mukose。JavaScript 版本：adryd325 与贡献者。

图集来源：https://github.com/adryd325/oneko.js/tree/5281d057c4ea9bd4f6f997ee96ba30491aed16c0
原 XBM：https://github.com/tie/oneko/tree/5bbb5113fb30eda4dc5ba74718b2de1979139587/bitmaps/neko
原蒙版：https://github.com/tie/oneko/tree/5bbb5113fb30eda4dc5ba74718b2de1979139587/bitmasks/neko
许可说明见 LICENSE-PUBLIC-DOMAIN.txt。

32 格图集逐像素匹配原 XBM 与蒙版，证据见 XBM-PIXEL-PROOF.json。全部动作按 oneko.js 的 spriteSets 坐标剪出，奔跑与抓挠 100ms/帧、睡眠 400ms/帧；待机、警觉、困倦各为真实单帧，通过 staticActions 显式声明。

本包保留动作循环，不移植浏览器鼠标追踪、随机行为选择、困倦进入睡眠的顺序调度或墙边判断。原脚本只用于静态读取坐标和节拍，未执行。
